#include "global.h"

typedef struct node_stack
{
	char data;
	struct node_stack *next;
}stack;
